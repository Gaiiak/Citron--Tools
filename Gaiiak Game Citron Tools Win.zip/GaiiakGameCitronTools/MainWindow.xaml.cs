﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using WinForms = System.Windows.Forms;
using MessageBox = System.Windows.MessageBox;

namespace GaiiakGameCitronTools
{
    public partial class MainWindow : Window
    {
        private readonly string _appBaseDir;
        private readonly string _configDir;
        private readonly string _kitsDir;
        private readonly string _versionsDir;
        private readonly string _tempDir;
        private readonly string _configFilePath;

        private readonly HttpClient _httpClient = new HttpClient();

        private const string CitronReleasesApiUrl =
            "https://api.github.com/repos/Zephyron-Dev/Citron-CI/releases";

        private const string KitDownloadUrl =
            "https://www.dropbox.com/scl/fi/emvh3yyb980mxmo0pvobn/Firmware21c.zip?rlkey=o22e1kivn6i3qs2zciz21v3fp&st=kp6jy2cw&dl=1";

        public MainWindow()
        {
            InitializeComponent();

            _appBaseDir = AppDomain.CurrentDomain.BaseDirectory;
            _configDir = Path.Combine(_appBaseDir, "Configuration");
            _kitsDir = Path.Combine(_appBaseDir, "Kits");
            _versionsDir = Path.Combine(_appBaseDir, "Versions Précédentes");
            _tempDir = Path.Combine(_appBaseDir, "Temp");
            _configFilePath = Path.Combine(_configDir, "Config.txt");

            _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("GaiiakGameCitronTools/1.0");

            Loaded += MainWindow_Loaded;
        }

        private async void MainWindow_Loaded(object? sender, RoutedEventArgs e)
        {
            try
            {
                InitDirectoriesAndConfig();
                await EnsureInstallPathAsync();
                AppendLog("Application prête.");
            }
            catch (Exception ex)
            {
                AppendLog($"Erreur au lancement : {ex.Message}");
                MessageBox.Show(ex.Message, "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        #region Initialisation & config

        private void InitDirectoriesAndConfig()
        {
            Directory.CreateDirectory(_configDir);
            Directory.CreateDirectory(_kitsDir);
            Directory.CreateDirectory(_versionsDir);
            Directory.CreateDirectory(_tempDir);

            if (!File.Exists(_configFilePath))
                File.WriteAllText(_configFilePath, string.Empty);
        }

        private async Task EnsureInstallPathAsync()
        {
            var path = await ReadInstallPathAsync();
            if (string.IsNullOrWhiteSpace(path) || !Directory.Exists(path))
            {
                AppendLog("Chemin d'installation non configuré. Merci de choisir un répertoire...");
                SelectInstallPathWithDialog();
            }
            else
            {
                AppendLog($"Chemin actuel : {path}");
            }
        }

        private Task<string> ReadInstallPathAsync()
        {
            if (!File.Exists(_configFilePath))
                return Task.FromResult(string.Empty);

            return Task.FromResult(File.ReadAllText(_configFilePath).Trim());
        }

        private void SaveInstallPath(string path)
        {
            File.WriteAllText(_configFilePath, path);
            AppendLog($"Chemin d'installation sauvegardé : {path}");
        }

        private void SelectInstallPathWithDialog()
        {
            using var dialog = new WinForms.FolderBrowserDialog
            {
                Description = "Sélectionnez le répertoire où installer Citron",
                ShowNewFolderButton = true
            };

            if (dialog.ShowDialog() == WinForms.DialogResult.OK &&
                !string.IsNullOrWhiteSpace(dialog.SelectedPath))
            {
                SaveInstallPath(dialog.SelectedPath);
            }
            else
            {
                MessageBox.Show(
                    "L'application ne peut pas fonctionner sans dossier d'installation.",
                    "Information",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
            }
        }

        private async Task<string> GetInstallPathOrAskAsync()
        {
            var path = await ReadInstallPathAsync();
            if (string.IsNullOrWhiteSpace(path) || !Directory.Exists(path))
            {
                SelectInstallPathWithDialog();
                path = await ReadInstallPathAsync();
            }

            if (string.IsNullOrWhiteSpace(path))
                throw new Exception("Chemin d'installation introuvable.");

            return path;
        }

        #endregion

        #region Utilitaires UI

        private void AppendLog(string message)
        {
            Dispatcher.Invoke(() =>
            {
                TxtLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {message}{Environment.NewLine}");
                TxtLog.ScrollToEnd();
            });
        }

        private void ShowProgressBar()
        {
            Dispatcher.Invoke(() =>
            {
                ProgressPanel.Visibility = Visibility.Visible;
                MainProgressBar.Value = 0;
            });
        }

        private void HideProgressBar()
        {
            Dispatcher.Invoke(() =>
            {
                ProgressPanel.Visibility = Visibility.Collapsed;
                MainProgressBar.Value = 0;
            });
        }

        private void SetProgress(double value)
        {
            Dispatcher.Invoke(() =>
            {
                value = Math.Clamp(value, 0, 100);
                MainProgressBar.Value = value;
                ProgressPanel.Visibility = Visibility.Visible;
            });
        }

        private void DisableButtons() => SetButtonsEnabled(false);
        private void EnableButtons() => SetButtonsEnabled(true);

        private void SetButtonsEnabled(bool enabled)
        {
            BtnCheckLatest.IsEnabled = enabled;
            BtnInstallDownloaded.IsEnabled = enabled;
            BtnPortable.IsEnabled = enabled;
            BtnInstallKit.IsEnabled = enabled;
            BtnOpenEmulatorFolder.IsEnabled = enabled;
            BtnLaunchEmulator.IsEnabled = enabled;
            BtnAutoSetup.IsEnabled = enabled;
            // BtnClearLog reste toujours actif
        }

        private string FormatReleaseDate(string? iso)
        {
            if (string.IsNullOrWhiteSpace(iso)) return "Inconnue";

            if (DateTimeOffset.TryParse(
                    iso,
                    CultureInfo.InvariantCulture,
                    DateTimeStyles.RoundtripKind,
                    out var dto))
            {
                return dto.ToLocalTime().ToString(CultureInfo.CurrentCulture);
            }

            return iso;
        }

        #endregion

        #region Téléchargement

        private async Task DownloadFileWithProgressAsync(string url, string destPath)
        {
            ShowProgressBar();
            SetProgress(0);

            using var response = await _httpClient.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
            response.EnsureSuccessStatusCode();

            long? total = response.Content.Headers.ContentLength;
            await using var input = await response.Content.ReadAsStreamAsync();
            await using var output = File.Create(destPath);

            byte[] buffer = new byte[8192];
            long totalRead = 0;
            int read;
            while ((read = await input.ReadAsync(buffer, 0, buffer.Length)) > 0)
            {
                await output.WriteAsync(buffer, 0, read);
                totalRead += read;

                if (total.HasValue && total.Value > 0)
                {
                    SetProgress(totalRead * 100.0 / total.Value);
                }
                else
                {
                    SetProgress(50);
                }
            }

            SetProgress(100);
        }

        #endregion

        #region Dernière version Citron (bouton manuel)

        private async void BtnCheckLatest_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DisableButtons();
                ShowProgressBar();
                AppendLog("Recherche de la dernière version Citron CI...");

                using var response = await _httpClient.GetAsync(CitronReleasesApiUrl);
                response.EnsureSuccessStatusCode();

                string json = await response.Content.ReadAsStringAsync();
                using var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;

                if (root.ValueKind != JsonValueKind.Array || root.GetArrayLength() == 0)
                    throw new Exception("Aucune release Citron trouvée.");

                var latest = root[0];

                string version =
                    latest.TryGetProperty("name", out var nameEl) ? (nameEl.GetString() ?? "") :
                    latest.TryGetProperty("tag_name", out var tagEl) ? (tagEl.GetString() ?? "") :
                    "Inconnue";

                string? publishedRaw =
                    latest.TryGetProperty("published_at", out var pubEl) ? pubEl.GetString() : null;

                string published = FormatReleaseDate(publishedRaw);

                TxtVersionName.Text = version;
                TxtVersionDate.Text = published;

                AppendLog($"Dernière version Citron : {version} ({published})");

                if (!latest.TryGetProperty("assets", out var assetsEl) ||
                    assetsEl.ValueKind != JsonValueKind.Array)
                    throw new Exception("Aucun asset trouvé dans la release.");

                var assets = assetsEl.EnumerateArray();

                var winAsset = assets.FirstOrDefault(a =>
                {
                    var n = a.TryGetProperty("name", out var nEl) ? nEl.GetString() ?? "" : "";
                    return n.Contains("windows", StringComparison.OrdinalIgnoreCase) &&
                           n.EndsWith(".zip", StringComparison.OrdinalIgnoreCase);
                });

                if (winAsset.ValueKind == JsonValueKind.Undefined)
                {
                    winAsset = assetsEl.EnumerateArray()
                        .FirstOrDefault(a =>
                            (a.TryGetProperty("name", out var nEl) ? nEl.GetString() ?? "" : "")
                            .EndsWith(".zip", StringComparison.OrdinalIgnoreCase));
                }

                if (winAsset.ValueKind == JsonValueKind.Undefined)
                    throw new Exception("Aucune archive .zip trouvée pour Citron.");

                string fileName =
                    winAsset.TryGetProperty("name", out var fnEl) ? (fnEl.GetString() ?? "citron.zip") : "citron.zip";
                string downloadUrl =
                    winAsset.TryGetProperty("browser_download_url", out var urlEl)
                        ? (urlEl.GetString() ?? "")
                        : "";

                if (string.IsNullOrWhiteSpace(downloadUrl))
                    throw new Exception("URL de téléchargement introuvable pour l'archive Citron.");

                string destPath = Path.Combine(_versionsDir, fileName);

                if (File.Exists(destPath))
                {
                    MessageBox.Show("Cette version est déjà téléchargée.", "Information",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    AppendLog("Version déjà présente.");
                    return;
                }

                var ask = MessageBox.Show(
                    $"Télécharger : {fileName} ?",
                    "Téléchargement Citron",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (ask != MessageBoxResult.Yes)
                {
                    AppendLog("Téléchargement annulé.");
                    return;
                }

                await DownloadFileWithProgressAsync(downloadUrl, destPath);
                AppendLog("Téléchargement OK → Installation Citron...");
                await InstallArchiveAsync(destPath);
                AppendLog("✔ Installation Citron terminée.");
            }
            catch (Exception ex)
            {
                AppendLog("Erreur Citron : " + ex.Message);
                MessageBox.Show(ex.Message, "Erreur Citron",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                HideProgressBar();
                EnableButtons();
            }
        }

        #endregion

        #region Installation archive Citron

        private async Task InstallArchiveAsync(string zipPath)
        {
            if (string.IsNullOrWhiteSpace(zipPath))
                throw new ArgumentException("zipPath vide.", nameof(zipPath));

            string installPath = await GetInstallPathOrAskAsync();

            // On repart sur un Temp propre pour l'extraction
            if (Directory.Exists(_tempDir))
                Directory.Delete(_tempDir, true);
            Directory.CreateDirectory(_tempDir);

            AppendLog("Décompression de l'archive Citron...");
            ZipFile.ExtractToDirectory(zipPath, _tempDir, true);

            string? exePath = Directory.GetFiles(_tempDir, "*.exe", SearchOption.AllDirectories)
                .FirstOrDefault();

            if (exePath == null)
                throw new Exception("Impossible de trouver un exécutable Citron dans l'archive.");

            string sourceRoot = Path.GetDirectoryName(exePath)!;
            string emulatorDir = Path.Combine(installPath, "EmulateurCitron");

            // NE PLUS SUPPRIMER LE DOSSIER EMULATEUR
            // On le crée s'il n'existe pas, sinon on le réutilise tel quel.
            if (!Directory.Exists(emulatorDir))
            {
                Directory.CreateDirectory(emulatorDir);
                AppendLog("Répertoire 'EmulateurCitron' créé.");
            }
            else
            {
                AppendLog("Répertoire 'EmulateurCitron' existant : mise à jour sans suppression (écrasement des fichiers).");
            }

            // On copie tous les fichiers de la nouvelle version vers EmulateurCitron
            // en écrasant ceux qui portent le même nom, sans toucher aux autres.
            CopyDir(sourceRoot, emulatorDir);

            // On peut nettoyer le répertoire Temp si on veut
            try
            {
                if (Directory.Exists(_tempDir))
                    Directory.Delete(_tempDir, true);
            }
            catch
            {
                // Pas grave si le nettoyage échoue, on ne bloque pas l'installation
            }

            AppendLog("✔ Emulateur Citron mis à jour (sans suppression du dossier existant).");
        }


        private void MoveDirectorySafe(string src, string dst)
        {
            string srcRoot = Path.GetPathRoot(src) ?? "";
            string dstRoot = Path.GetPathRoot(dst) ?? "";

            if (!string.Equals(srcRoot, dstRoot, StringComparison.OrdinalIgnoreCase))
            {
                AppendLog("Volumes différents → copie des fichiers...");
                CopyDir(src, dst);
                Directory.Delete(src, true);
            }
            else
            {
                Directory.Move(src, dst);
            }
        }

        private static void CopyDir(string src, string dst)
        {
            Directory.CreateDirectory(dst);

            foreach (var dir in Directory.GetDirectories(src, "*", SearchOption.AllDirectories))
            {
                var rel = dir.Substring(src.Length)
                             .TrimStart(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                Directory.CreateDirectory(Path.Combine(dst, rel));
            }

            foreach (var file in Directory.GetFiles(src, "*.*", SearchOption.AllDirectories))
            {
                var rel = file.Substring(src.Length)
                              .TrimStart(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                var target = Path.Combine(dst, rel);
                Directory.CreateDirectory(Path.GetDirectoryName(target)!);
                File.Copy(file, target, true);
            }
        }

        #endregion

        #region Installer une version téléchargée

        private async void BtnInstallDownloaded_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DisableButtons();

                string[] zips = Directory.GetFiles(_versionsDir, "*.zip");

                if (zips.Length == 0)
                {
                    MessageBox.Show("Aucune version téléchargée.", "Information",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    AppendLog("Aucune archive trouvée dans 'Versions Précédentes'.");
                    return;
                }

                var select = new SelectVersionWindow(zips) { Owner = this };
                bool? result = select.ShowDialog();

                if (result == true && !string.IsNullOrEmpty(select.SelectedArchivePath))
                {
                    await InstallArchiveAsync(select.SelectedArchivePath);
                    AppendLog("✔ Installation de la version de Citron sélectionnée terminée.");
                }
                else
                {
                    AppendLog("Installation annulée par l'utilisateur.");
                }
            }
            catch (Exception ex)
            {
                AppendLog("Erreur : " + ex.Message);
                MessageBox.Show(ex.Message, "Erreur",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                EnableButtons();
            }
        }

        #endregion

        #region Mode portable (dossier user)

        private async void BtnPortable_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DisableButtons();
                AppendLog("Gestion du mode portable Citron...");

                string install = await GetInstallPathOrAskAsync();
                string emulator = Path.Combine(install, "EmulateurCitron");

                if (!Directory.Exists(emulator))
                {
                    MessageBox.Show(
                        "Le répertoire 'EmulateurCitron' n'existe pas dans le chemin d'installation.",
                        "Information",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                    AppendLog("Répertoire 'EmulateurCitron' introuvable.");
                    return;
                }

                string userDir = Path.Combine(emulator, "user");

                if (Directory.Exists(userDir))
                {
                    AppendLog("Mode portable déjà actif (dossier 'user' présent).");

                    var keep = MessageBox.Show(
                        "Le mode portable est déjà actif (dossier 'user' présent)." +
                        Environment.NewLine +
                        "Souhaitez-vous le conserver ?",
                        "Mode portable Citron",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Question);

                    if (keep == MessageBoxResult.Yes)
                    {
                        AppendLog("Mode portable conservé.");
                        return;
                    }

                    var confirm = MessageBox.Show(
                        "ATTENTION : la désactivation du mode portable va supprimer les configurations et les sauvegardes" +
                        " contenues dans le dossier 'user'." +
                        Environment.NewLine +
                        "Êtes-vous sûr de vouloir continuer ?",
                        "Confirmer la désactivation du mode portable",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Warning);

                    if (confirm == MessageBoxResult.Yes)
                    {
                        Directory.Delete(userDir, true);
                        AppendLog("Mode portable désactivé.");
                        MessageBox.Show(
                            "Mode portable désactivé. Les configurations et sauvegardes du dossier ont été supprimées.",
                            "Information",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);
                    }
                    else
                    {
                        AppendLog("Désactivation du mode portable annulée par l'utilisateur.");
                    }
                }
                else
                {
                    Directory.CreateDirectory(userDir);
                    AppendLog("Mode portable activé.");
                    MessageBox.Show(
                        "Mode portable activé.",
                        "Information",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                AppendLog("Erreur : " + ex.Message);
                MessageBox.Show(ex.Message, "Erreur",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                EnableButtons();
            }
        }

        #endregion

        #region Kits (Firmware21c : nand/keys/config → user)

        private async void BtnInstallKit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DisableButtons();
                ShowProgressBar();
                AppendLog("Gestion des Kits Citron...");

                string[] kits = Directory.GetFiles(_kitsDir, "*.zip");
                string zipToUse;

                if (kits.Length == 0)
                {
                    var ask = MessageBox.Show(
                        "Aucun Kit n'est présent dans le dossier 'Kits'." +
                        Environment.NewLine +
                        "Souhaitez-vous télécharger le Kit maintenant ?",
                        "Kits Citron",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Question);

                    if (ask != MessageBoxResult.Yes)
                    {
                        AppendLog("Téléchargement du Kit Citron annulé.");
                        return;
                    }

                    zipToUse = Path.Combine(_kitsDir, "Firmware21c.zip");
                    AppendLog("Téléchargement du Kit Citron...");
                    await DownloadFileWithProgressAsync(KitDownloadUrl, zipToUse);
                }
                else
                {
                    var selectWindow = new SelectVersionWindow(kits) { Owner = this };
                    if (selectWindow.ShowDialog() == true &&
                        !string.IsNullOrEmpty(selectWindow.SelectedArchivePath))
                    {
                        zipToUse = selectWindow.SelectedArchivePath;
                    }
                    else
                    {
                        AppendLog("Installation du Kit Citron annulée par l'utilisateur.");
                        return;
                    }
                }

                if (Directory.Exists(_tempDir))
                    Directory.Delete(_tempDir, true);
                Directory.CreateDirectory(_tempDir);

                ZipFile.ExtractToDirectory(zipToUse, _tempDir, true);
                AppendLog("Traitement en cours...");

                await ProcessKitInTempAsync();

                AppendLog("✔ Kit Citron installé.");
            }
            catch (Exception ex)
            {
                AppendLog("Erreur Kits Citron : " + ex.Message);
                MessageBox.Show(ex.Message, "Erreur Kits Citron",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                HideProgressBar();
                EnableButtons();
            }
        }

        private async Task ProcessKitInTempAsync()
        {
            string install = await GetInstallPathOrAskAsync();
            string emulatorDir = Path.Combine(install, "EmulateurCitron");
            if (!Directory.Exists(emulatorDir))
            {
                Directory.CreateDirectory(emulatorDir);
                AppendLog("Répertoire 'EmulateurCitron' créé pour le Kit.");
            }

            string userDir = Path.Combine(emulatorDir, "user");
            Directory.CreateDirectory(userDir);

            string? nandSrc = FindDirectoryInTemp("nand");
            string? keysSrc = FindDirectoryInTemp("keys");
            string? configSrc = FindDirectoryInTemp("config");

            if (nandSrc != null)
            {
                string nandDst = Path.Combine(userDir, "nand");
                if (Directory.Exists(nandDst)) Directory.Delete(nandDst, true);
                MoveDirectorySafe(nandSrc, nandDst);
            }
            else
            {
                AppendLog("Dossier 'nand' introuvable dans le Kit.");
            }

            if (configSrc != null)
            {
                string configDst = Path.Combine(userDir, "config");
                if (Directory.Exists(configDst)) Directory.Delete(configDst, true);
                MoveDirectorySafe(configSrc, configDst);
            }
            else
            {
                AppendLog("Dossier 'config' introuvable dans le Kit.");
            }

            if (keysSrc != null)
            {
                string keysDst = Path.Combine(userDir, "keys");
                if (Directory.Exists(keysDst)) Directory.Delete(keysDst, true);
                MoveDirectorySafe(keysSrc, keysDst);

                string k1 = Path.Combine(keysDst, "k1.dll");
                string prod = Path.Combine(keysDst, "prod.keys");
                if (File.Exists(k1))
                {
                    if (File.Exists(prod)) File.Delete(prod);
                    File.Move(k1, prod);
                }
                else
                {
                    AppendLog("k1.dll introuvable dans le Kit.");
                }

                string k2 = Path.Combine(keysDst, "k2.dll");
                string title = Path.Combine(keysDst, "title.keys");
                if (File.Exists(k2))
                {
                    if (File.Exists(title)) File.Delete(title);
                    File.Move(k2, title);
                }
                else
                {
                    AppendLog("k2.dll introuvable dans le Kit.");
                }
            }
            else
            {
                AppendLog("Dossier 'keys' introuvable dans le Kit.");
            }

            if (Directory.Exists(_tempDir))
            {
                Directory.Delete(_tempDir, true);
            }
        }

        private string? FindDirectoryInTemp(string name)
        {
            string direct = Path.Combine(_tempDir, name);
            if (Directory.Exists(direct)) return direct;

            return Directory.GetDirectories(_tempDir, name, SearchOption.AllDirectories)
                .FirstOrDefault();
        }

        #endregion

        #region Ouvrir dossier EmulateurCitron

        private async void BtnOpenEmulatorFolder_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string install = await GetInstallPathOrAskAsync();
                string emulatorDir = Path.Combine(install, "EmulateurCitron");

                if (!Directory.Exists(emulatorDir))
                {
                    MessageBox.Show(
                        "Le répertoire 'EmulateurCitron' est introuvable.",
                        "Information",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                    AppendLog("Ouverture du dossier EmulateurCitron impossible (dossier introuvable).");
                    return;
                }

                Process.Start("explorer.exe", emulatorDir);
                AppendLog("Dossier EmulateurCitron ouvert dans l'explorateur.");
            }
            catch (Exception ex)
            {
                AppendLog("Erreur ouverture dossier EmulateurCitron : " + ex.Message);
                MessageBox.Show(ex.Message, "Erreur",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        #endregion

        #region Effacer le journal

        private void BtnClearLog_Click(object sender, RoutedEventArgs e)
        {
            TxtLog.Clear();
        }

        #endregion

        #region Lancer Citron

        private async void BtnLaunchEmulator_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                AppendLog("Tentative de lancement de Citron...");

                string install = await GetInstallPathOrAskAsync();
                string emulatorDir = Path.Combine(install, "EmulateurCitron");

                if (!Directory.Exists(emulatorDir))
                {
                    MessageBox.Show(
                        "Le dossier 'EmulateurCitron' est introuvable. Installe d'abord une version de Citron.",
                        "Information",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                    AppendLog("Lancement annulé : répertoire EmulateurCitron introuvable.");
                    return;
                }

                string exePath = Path.Combine(emulatorDir, "Citron.exe");
                if (!File.Exists(exePath))
                {
                    exePath = Directory.GetFiles(emulatorDir, "*.exe", SearchOption.AllDirectories)
                        .FirstOrDefault() ?? string.Empty;
                }

                if (string.IsNullOrEmpty(exePath) || !File.Exists(exePath))
                {
                    MessageBox.Show(
                        "Impossible de trouver l'exécutable Citron dans le dossier EmulateurCitron.",
                        "Information",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                    AppendLog("Aucun exécutable Citron trouvé dans EmulateurCitron.");
                    return;
                }

                var psi = new ProcessStartInfo(exePath)
                {
                    WorkingDirectory = Path.GetDirectoryName(exePath)!,
                    UseShellExecute = true
                };

                Process.Start(psi);
                AppendLog($"Lancement de l'émulateur Citron : {exePath}");
            }
            catch (Exception ex)
            {
                AppendLog("Erreur lors du lancement de Citron : " + ex.Message);
                MessageBox.Show(ex.Message, "Erreur lancement Citron",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        #endregion

        #region Installation automatique complète + lancement

        private async void BtnAutoSetup_Click(object sender, RoutedEventArgs e)
        {
            await AutoSetupEverythingAsync();
        }

        private async Task AutoSetupEverythingAsync()
        {
            try
            {
                DisableButtons();
                ShowProgressBar();
                AppendLog("[AUTO] Démarrage de l'installation automatique de Citron...");

                // FORCER la sélection du dossier (même si déjà configuré)
                SelectInstallPathWithDialog();
                string installPath = await GetInstallPathOrAskAsync();
                AppendLog($"[AUTO] Dossier d'installation utilisé : {installPath}");

                // 1) Installer la dernière version Citron CI
                await AutoInstallLatestCitronAsync();

                // 2) Installer le Kit Citron
                await AutoInstallKitAsync();

                // 3) Lancer l'émulateur
                AppendLog("[AUTO] Lancement de l'émulateur...");
                await Dispatcher.InvokeAsync(() => BtnLaunchEmulator_Click(this, new RoutedEventArgs()));

                AppendLog("[AUTO] ✔ Séquence automatique terminée.");
            }
            catch (Exception ex)
            {
                AppendLog("[AUTO][ERREUR] " + ex.Message);
                MessageBox.Show(ex.Message, "Erreur installation automatique",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                HideProgressBar();
                EnableButtons();
            }
        }


        private async Task AutoInstallLatestCitronAsync()
        {
            AppendLog("[AUTO] Recherche de la dernière version Citron CI...");

            using var response = await _httpClient.GetAsync(CitronReleasesApiUrl);
            response.EnsureSuccessStatusCode();

            string json = await response.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;

            if (root.ValueKind != JsonValueKind.Array || root.GetArrayLength() == 0)
                throw new Exception("Aucune release Citron trouvée.");

            var latest = root[0];

            string version =
                latest.TryGetProperty("name", out var nameEl) ? (nameEl.GetString() ?? "") :
                latest.TryGetProperty("tag_name", out var tagEl) ? (tagEl.GetString() ?? "") :
                "Inconnue";

            string? publishedRaw =
                latest.TryGetProperty("published_at", out var pubEl) ? pubEl.GetString() : null;

            string published = FormatReleaseDate(publishedRaw);

            TxtVersionName.Text = version;
            TxtVersionDate.Text = published;

            AppendLog($"[AUTO] Dernière version Citron : {version} ({published})");

            if (!latest.TryGetProperty("assets", out var assetsEl) ||
                assetsEl.ValueKind != JsonValueKind.Array)
                throw new Exception("Aucun asset trouvé dans la release.");

            var assets = assetsEl.EnumerateArray();

            var winAsset = assets.FirstOrDefault(a =>
            {
                var n = a.TryGetProperty("name", out var nEl) ? nEl.GetString() ?? "" : "";
                return n.Contains("windows", StringComparison.OrdinalIgnoreCase) &&
                       n.EndsWith(".zip", StringComparison.OrdinalIgnoreCase);
            });

            if (winAsset.ValueKind == JsonValueKind.Undefined)
            {
                winAsset = assetsEl.EnumerateArray()
                    .FirstOrDefault(a =>
                        (a.TryGetProperty("name", out var nEl) ? nEl.GetString() ?? "" : "")
                        .EndsWith(".zip", StringComparison.OrdinalIgnoreCase));
            }

            if (winAsset.ValueKind == JsonValueKind.Undefined)
                throw new Exception("Aucune archive .zip trouvée pour Citron.");

            string fileName =
                winAsset.TryGetProperty("name", out var fnEl) ? (fnEl.GetString() ?? "citron.zip") : "citron.zip";
            string downloadUrl =
                winAsset.TryGetProperty("browser_download_url", out var urlEl)
                    ? (urlEl.GetString() ?? "")
                    : "";

            if (string.IsNullOrWhiteSpace(downloadUrl))
                throw new Exception("URL de téléchargement introuvable pour l'archive Citron.");

            string destPath = Path.Combine(_versionsDir, fileName);

            if (File.Exists(destPath))
            {
                AppendLog("[AUTO] Archive déjà présente → installation de cette version...");
                await InstallArchiveAsync(destPath);
                AppendLog("[AUTO] ✔ Citron installé depuis l'archive déjà téléchargée.");
            }
            else
            {
                AppendLog($"[AUTO] Téléchargement de {fileName}...");
                await DownloadFileWithProgressAsync(downloadUrl, destPath);
                AppendLog("[AUTO] Téléchargement OK → Installation Citron...");
                await InstallArchiveAsync(destPath);
                AppendLog("[AUTO] ✔ Citron installé depuis la dernière release.");
            }
        }

        private async Task AutoInstallKitAsync()
        {
            AppendLog("[AUTO] Préparation du Kit Citron...");

            string[] kits = Directory.GetFiles(_kitsDir, "*.zip");
            string zipToUse;

            if (kits.Length == 0)
            {
                zipToUse = Path.Combine(_kitsDir, "Firmware21c.zip");
                AppendLog("[AUTO] Aucun Kit trouvé → téléchargement automatique du Kit par défaut...");
                await DownloadFileWithProgressAsync(KitDownloadUrl, zipToUse);
            }
            else
            {
                string? firmware = kits.FirstOrDefault(p =>
                    Path.GetFileName(p).Contains("Firmware21c", StringComparison.OrdinalIgnoreCase));

                if (firmware != null)
                {
                    zipToUse = firmware;
                }
                else
                {
                    // À défaut : le plus récent
                    zipToUse = kits.OrderByDescending(File.GetCreationTimeUtc).First();
                }

                AppendLog($"[AUTO] Kit sélectionné : {Path.GetFileName(zipToUse)}");
            }

            if (Directory.Exists(_tempDir))
                Directory.Delete(_tempDir, true);
            Directory.CreateDirectory(_tempDir);

            AppendLog("[AUTO] Décompression du Kit...");
            ZipFile.ExtractToDirectory(zipToUse, _tempDir, true);
            AppendLog("[AUTO] Traitement du Kit...");
            await ProcessKitInTempAsync();
            AppendLog("[AUTO] ✔ Kit Citron installé.");
        }

        #endregion
    }
}
