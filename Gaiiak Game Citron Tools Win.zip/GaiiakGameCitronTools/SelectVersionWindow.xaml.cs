using System;
using System.IO;
using System.Linq;
using System.Windows;
using MessageBox = System.Windows.MessageBox;

namespace GaiiakGameCitronTools
{
    public partial class SelectVersionWindow : Window
    {
        public string? SelectedArchivePath { get; private set; }

        private string[] _archives = Array.Empty<string>();

        public SelectVersionWindow(string[] archives)
        {
            InitializeComponent();

            // Tri nom décroissant (archives récentes en haut)
            _archives = archives
                .OrderByDescending(Path.GetFileName)
                .ToArray();

            RefreshList();
        }

        private void RefreshList()
        {
            ListArchives.ItemsSource = null;
            ListArchives.ItemsSource = _archives
                .Select(p => Path.GetFileName(p))
                .ToList();
        }

        private void BtnOk_Click(object sender, RoutedEventArgs e)
        {
            ConfirmSelection();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void ListArchives_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            ConfirmSelection();
        }

        private void ConfirmSelection()
        {
            if (ListArchives.SelectedIndex < 0 ||
                ListArchives.SelectedIndex >= _archives.Length)
            {
                MessageBox.Show(
                    "Veuillez sélectionner une archive.",
                    "Information",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
                return;
            }

            SelectedArchivePath = _archives[ListArchives.SelectedIndex];
            DialogResult = true;
            Close();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (ListArchives.SelectedIndex < 0 ||
                ListArchives.SelectedIndex >= _archives.Length)
            {
                MessageBox.Show(
                    "Veuillez sélectionner une archive à supprimer.",
                    "Information",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
                return;
            }

            string filePath = _archives[ListArchives.SelectedIndex];
            string fileName = Path.GetFileName(filePath);

            var confirm = MessageBox.Show(
                $"Supprimer l'archive '{fileName}' ?",
                "Confirmation suppression",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (confirm != MessageBoxResult.Yes)
                return;

            try
            {
                if (File.Exists(filePath))
                    File.Delete(filePath);

                _archives = _archives
                    .Where(p => !string.Equals(p, filePath, StringComparison.OrdinalIgnoreCase))
                    .ToArray();

                RefreshList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Erreur lors de la suppression : " + ex.Message,
                    "Erreur",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }
    }
}
